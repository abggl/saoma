module.exports = async (ctx) => {
  let userId, page = 1, pageSize = 20;
  
  if (ctx.args && ctx.args.body) {
    try {
      const body = typeof ctx.args.body === 'string' ? JSON.parse(ctx.args.body) : ctx.args.body;
      userId = body.userId;
      page = body.page || 1;
      pageSize = body.pageSize || 20;
    } catch (e) {
      userId = ctx.args.userId;
      page = ctx.args.page || 1;
      pageSize = ctx.args.pageSize || 20;
    }
  } else if (ctx.args) {
    userId = ctx.args.userId;
    page = ctx.args.page || 1;
    pageSize = ctx.args.pageSize || 20;
  }

  if (!userId) {
    return {
      success: false,
      errorMessage: '用户ID不能为空'
    };
  }

  try {
    const db = ctx.mpserverless.db;
    const recordsCollection = db.collection('records');

    const skip = (parseInt(page) - 1) * parseInt(pageSize);
    const limit = parseInt(pageSize);

    const query = { 'submitter.userId': userId };

    const countResult = await recordsCollection.count(query);
    const total = countResult || 0;

    const records = await recordsCollection
      .find(query, {
        sort: { submitTime: -1 },
        skip: skip,
        limit: limit
      });

    return {
      success: true,
      data: {
        list: records || [],
        total: total,
        page: parseInt(page),
        pageSize: limit,
        hasMore: skip + (records ? records.length : 0) < total
      }
    };

  } catch (error) {
    console.error('getHistory云函数执行失败:', error);
    return {
      success: false,
      errorMessage: `查询失败: ${error.message}`
    };
  }
};
